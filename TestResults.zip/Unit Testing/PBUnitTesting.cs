﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PhoneBook2;

namespace Unit_Testing
{
    [TestClass]
    public class PhonebookUnitTesting
    {
        [TestMethod]
        public void ReturnNumberofEntries()
        {
            AdressBook adressBook = new AdressBook();
            Assert.IsNotNull(!(adressBook.GetNumberOfEntries() == 0), "values exist in the address book");
        }

        [TestMethod]
        public void AddressBookHasNoEntriesAtStart()
        {
            AdressBook phoneBook = new AdressBook();
            Assert.AreEqual(0, phoneBook.GetNumberOfEntries(), "No entries to start with.");
        }

        [TestMethod]
        public void Add()
        {
            AdressBook adressBook = new AdressBook();
            User userdetails = new User(1, "Vilma", "michael", "uppsala", "0754563254");
            adressBook.Add(userdetails);
        }

        [TestMethod]
        public void CannotAddNullNamedEntry()
        {
            AdressBook phoneBook = new AdressBook();
            User userdetail = new User(null, "Vilma", "uppsala", "0754563254");
            Assert.ThrowsException<ArgumentNullException>(() => phoneBook.Add(null));
        }

        [TestMethod]
        public void RetrieveByPersonalId()
        {
            AdressBook adressBook = new AdressBook();
            User userdetails = new User(1, "Vilma", "michael", "uppsala", "0754563254");
            adressBook.RetrieveByPersonalId(userdetails);

        }
        [TestMethod]
        public void CannotRetrieveNullNamedEntry()
        {
            AdressBook phoneBook = new AdressBook();
            User userdetails = new User(-1, "Vilma", null, "uppsala", "0754563254");
            Assert.ThrowsException<ArgumentNullException>(() => phoneBook.RetrieveByPersonalId(userdetails));
        }

        [TestMethod]
        public void RemoveUser()
        {
            AdressBook adressBook = new AdressBook();
            User userdetails = new User(1, "Vilma", "michael", "uppsala", "0754563254");
            adressBook.RemoveUser(userdetails);

        }
        [TestMethod]
        public void CannotRemoveNullNamedEntry()
        {
            AdressBook phoneBook = new AdressBook();
            User userdetails = new User(-1,"Vilma", null, "uppsala", "0754563254");
            Assert.ThrowsException<ArgumentNullException>(() => phoneBook.RemoveUser(userdetails));
        }
        [TestMethod]
        public void UpdateUser()
        {
            AdressBook adressBook = new AdressBook();
            User userdetails = new User(1, "Vilma", "michael", "uppsala", "0754563254");
            adressBook.UpdateUser(userdetails);
        }

        [TestMethod]
        public void SearchUser()
        {
            AdressBook adressBook = new AdressBook();
            User userdetails = new User(1, "Vilma", "michael", "uppsala", "0754563254");
            adressBook.SearchByPersonalId(userdetails);

        }
        [TestMethod]
        public void CannotSearchNullNamedEntry()
        {
            AdressBook phoneBook = new AdressBook();
            User userdetail = new User(-1, "Vilma", null, "uppsala", "0754563254");
            Assert.ThrowsException<ArgumentNullException>(() => phoneBook.SearchByPersonalId(userdetail));
        }


    }

}
